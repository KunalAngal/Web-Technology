package com.example.Setter_Injection_collection;

public class Car {
	private int speed;
	public void setData(int speed) {
		this.speed=speed;
	}
	public int getData2()
	{
		return speed;
	}
}
