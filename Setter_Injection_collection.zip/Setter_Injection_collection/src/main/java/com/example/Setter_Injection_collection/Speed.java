package com.example.Setter_Injection_collection;

import java.util.List;

public class Speed {
	
	private List<Car> car;
	public void setData(List<Car> car) {
		this.car=car;
	}
	public void getData1() {
		for(Car c:car) {
			int speed = c.getData2();
            System.out.println("The Speed of car is : " + speed + " km/hr");
		}
		
	}
}
