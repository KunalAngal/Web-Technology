package com.example.Setter_Injection_collection;

import java.util.Arrays;
import java.util.List;
public class App 
{
    public static void main( String[] args )
    {
        Car c1=new Car();
        Car c2=new Car();
        c1.setData(10);
        c2.setData(20);
        List<Car> carList = Arrays.asList(c1, c2);

        Speed s2 = new Speed();
        s2.setData(carList);
        s2.getData1();
    }
}
