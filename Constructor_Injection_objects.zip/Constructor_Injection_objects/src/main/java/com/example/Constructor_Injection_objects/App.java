package com.example.Constructor_Injection_objects;
public class App 
{
    public static void main( String[] args )
    {
    	Car c1 = new Car(10);
		Speed s1 = new Speed(c1);
		s1.getTheData();

    }
}
