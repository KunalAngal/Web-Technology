package com.example.Constructor_Injection_objects;
//second file
public class Speed {
	private Car car;
	public Speed(Car car) {
		this.car = car;
	}
	public void getTheData()
	{
		int d1= car.showSpeed();
		System.out.println("The Speed of car is : "+d1+" km/hr");
	}
}
