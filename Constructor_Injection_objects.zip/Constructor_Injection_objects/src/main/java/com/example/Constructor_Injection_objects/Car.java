package com.example.Constructor_Injection_objects;
//first file
public class Car {
	private int speed;
	public Car(int speed) {
		this.speed=speed;
	}
	public int showSpeed()
	{
		return speed;
	}
}
