package com.rit.spring.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.rit.spring.Entity.Student;



public interface StudentRepository extends JpaRepository<Student, Integer>{

}


