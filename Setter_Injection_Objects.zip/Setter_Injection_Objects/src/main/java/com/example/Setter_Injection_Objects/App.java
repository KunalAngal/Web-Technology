package com.example.Setter_Injection_Objects;


public class App 
{
    public static void main( String[] args )
    {
        Car c1=new Car();
        Speed s1=new Speed();
        c1.setData(10);
        s1.setData(c1);
        s1.getData1();
    }
}
