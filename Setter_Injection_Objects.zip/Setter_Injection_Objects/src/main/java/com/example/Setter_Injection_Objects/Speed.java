package com.example.Setter_Injection_Objects;

public class Speed {
private Car car;
public void setData(Car car) {
	this.car=car;
}
public void getData1() {
	int a1=car.getData();
	System.out.println("Speed of car"+a1+"km");
}
}
