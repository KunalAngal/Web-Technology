package com.example.Setter_Injection_Objects;

public class Car {
	private int speed;
	public void setData(int speed) {
		this.speed=speed;
	}
	public int getData()
	{
		return speed;
	}
}
