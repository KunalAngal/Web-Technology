package com.example.Constructor_Injection_Collection;
//main file
import java.util.Arrays;
import java.util.List;

public class App 
{
    public static void main( String[] args )
    {
    	   Car c1 = new Car(10);
           Car c2 = new Car(20);
           List<Car> carList = Arrays.asList(c1, c2);

           Speed s1 = new Speed(carList);
           s1.getTheData();

    }
}
