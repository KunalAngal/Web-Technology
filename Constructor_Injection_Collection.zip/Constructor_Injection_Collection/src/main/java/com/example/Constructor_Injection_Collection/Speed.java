package com.example.Constructor_Injection_Collection;
//second file
import java.util.List;

public class Speed {
	private List<Car> car;
	public Speed(List<Car> car) {
		this.car = car;
	}

	public void getTheData() {
        for (Car cars : car) {
            int speed = cars.showSpeed();
            System.out.println("The Speed of car is : " + speed + " km/hr");
        }
    }

}
